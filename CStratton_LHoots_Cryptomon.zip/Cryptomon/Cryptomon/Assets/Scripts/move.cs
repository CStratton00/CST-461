using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    public string moveName;
    public int damage;
    public int missRate;
}
