using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cryptomon : MonoBehaviour
{
    public string cryptomonName = "";
    public int hp = 0;
    public int speed = 0;
    public string owner = "";
    public move[] moves = new move[2];
}